if (/Android|webOS|iPhone|iPad|iPod|BlackBerry|IEMobile|Opera Mini/i.test(navigator.userAgent)) {
    // 如果用户使用移动设备，显示警告信息
    alert("抱歉,本网站暂不支持手机端访问。手机端访问本网站页面布局可能异常。请使用电脑访问。")
}