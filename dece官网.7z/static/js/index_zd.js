// 此部分转载naturo工作室官网，原创：李官阳
var dx = "color: red;font-size: 13px;";
var c="color:blue;font-size:13px"
console.log("%c欢迎来到deqecraft工作室官网",dx);
console.log("%c我们工作室自由",dx);
console.log("%c您的体验是您对我们的帮助",dx);
console.log("%c欢迎您加入我们",dx);
console.log("%c该部分转载naturo工作室官网，原创：李官阳",c);
